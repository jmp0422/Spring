package com.multi.hw;

public class HW1 {
    public static void main(String[] args) {
        HW1_1 member1 = new HW1_1("자바", "14:30", "홍길동");
        HW1_1 member2 = new HW1_1("JSP", "9:30", "김길동");
        System.out.println(member1);
        System.out.println(member2);
    }

}
