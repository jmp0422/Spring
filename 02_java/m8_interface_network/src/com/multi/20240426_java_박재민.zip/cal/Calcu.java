package com.multi.hw.cal;

public interface Calcu {

    public final String CA  = "계산을 합니다.";

    public abstract void sum(int x, int y);
    public abstract void sub(int x, int y);
    public abstract void mul(int x, int y);
    public abstract void div(int x, int y);


}
