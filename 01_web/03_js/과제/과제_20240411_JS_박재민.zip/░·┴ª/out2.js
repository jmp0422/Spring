function 여행하다(){
    alert("여기는 어떠신가요?")
    location.href = "https://pkgtour.naver.com/products/youtourbus/FUK-DYB-20240426"
}
function 쉬다(){
    alert("이런 음악을 들으며 쉬시는 것은 어떠실까요?")
    location.href = "https://www.youtube.com/watch?v=mWASFFB8YFY"
}